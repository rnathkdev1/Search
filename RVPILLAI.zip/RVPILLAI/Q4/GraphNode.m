classdef GraphNode < handle
    
    properties
        
        nextNode;
        state;
        % parent_node;
        heuristic;
        
        nodeNum;
    end
    
    
    methods
        function this=GraphNode()
            
            this.nodeNum=[];
            this.nextNode=[];
            this.heuristic=[];
            
            % node_num,node_1,node_2,node_3,node_4,heuristic_1,heuristic_2,heuristic_3,heuristic_4
%             if nargin==
%             this.node_num=node_num;
%             this.node(1)=node_1;
%             this.node(2)=node_2;
%             this.node(3)=node_3;
%             this.node(4)=node_4;
%             
%             this.heuristic_1=heuristic_1;
%             this.heuristic_2=heuristic_2;
%             this.heuristic_3=heuristic_3;
%             this.heuristic_4=heuristic_4;
            
        end
        
        
            
            
       
        
    end
end

            
        