function keepgoing_c(Start,forbidden,Goal,path)




end
